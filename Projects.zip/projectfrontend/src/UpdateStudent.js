import { useEffect, useState, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

function UpdateStudent() {
    const navigate = useNavigate();
    const { std_id } = useParams();
    const fileInputRef = useRef(null);

    const [student, setStudent] = useState({
        std_name: "",
        std_fname: "",
        std_mname: "",
        std_dob: "",
        std_email: "",
        std_phone: "",
        std_course: "",
        std_gender: "",
        std_sports: "",
        std_photo: null, // can be File or Base64 string from backend
    });

    const [message, setMessage] = useState("");

    // Fetch student data
    useEffect(() => {
        if (std_id) {
            axios
                .get(`http://localhost:8095/student/displayStudent/${std_id}`)
                .then((response) => {
                    const data = response.data;

                    // Format DOB for date input
                    if (data.std_dob) {
                        data.std_dob = new Date(data.std_dob).toISOString().split("T")[0];
                    }

                    // Convert byte array photo to Base64 string if needed
                    if (data.std_photo && data.std_photo.length > 0) {
                        const base64Photo =
                            typeof data.std_photo === "string"
                                ? data.std_photo
                                : btoa(
                                    new Uint8Array(data.std_photo).reduce(
                                        (acc, byte) => acc + String.fromCharCode(byte),
                                        ""
                                    )
                                );
                        data.std_photo = `data:image/jpeg;base64,${base64Photo}`;
                    }

                    setStudent(data);
                })
                .catch((error) => console.error("Error fetching student:", error));
        }
    }, [std_id]);

    // Handle input changes
    const handleChange = (e) => {
        const { name, value, files } = e.target;
        if (name === "std_photo") {
            setStudent({ ...student, [name]: files[0] });
        } else {
            setStudent({ ...student, [name]: value });
        }
    };

    // Remove photo
    const handleRemovePhoto = () => {
        setStudent({ ...student, std_photo: null });
        fileInputRef.current.value = null;
    };

    // Submit updated data
    const handleUpdate = async (e) => {
        e.preventDefault();
        try {
            const formData = new FormData();
            Object.entries(student).forEach(([key, value]) => {
                if (key === "std_photo") {
                    if (value instanceof File) {
                        formData.append(key, value);
                    }
                } else if (value !== null) {
                    formData.append(key, value);
                }
            });

            await axios.put(
                `http://localhost:8095/student/update/${std_id}`,
                formData,
                {
                    headers: { "Content-Type": "multipart/form-data" },
                }
            );

            setMessage("Student updated successfully!");
            setTimeout(() => navigate("/view"), 2000);
        } catch (error) {
            console.error("Error updating student:", error);
            setMessage("Failed to update student. Please try again.");
        }
    };

    return (
        <div className="container text-center mt-3 mb-3">
            <form
                onSubmit={handleUpdate}
                className="form text-center w-50 mt-3 p-5 m-auto border border-dark rounded"
            >
                <h2>Update Student</h2>
                {message && <p className="alert alert-info">{message}</p>}

                <input
                    type="text"
                    placeholder="Student Name"
                    name="std_name"
                    value={student.std_name}
                    onChange={handleChange}
                    className="form-control p-2 rounded-pill"
                />
                <br />
                <input
                    type="text"
                    placeholder="Father Name"
                    name="std_fname"
                    value={student.std_fname}
                    onChange={handleChange}
                    className="form-control p-2 rounded-pill"
                />
                <br />
                <input
                    type="text"
                    placeholder="Mother Name"
                    name="std_mname"
                    value={student.std_mname}
                    onChange={handleChange}
                    className="form-control p-2 rounded-pill"
                />
                <br />
                <input
                    type="date"
                    placeholder="DOB"
                    name="std_dob"
                    value={student.std_dob}
                    onChange={handleChange}
                    className="form-control p-2 rounded-pill"
                />
                <br />
                <input
                    type="email"
                    placeholder="Email"
                    name="std_email"
                    value={student.std_email}
                    onChange={handleChange}
                    className="form-control p-2 rounded-pill"
                />
                <br />
                <input
                    type="text"
                    placeholder="Phone"
                    name="std_phone"
                    value={student.std_phone}
                    onChange={handleChange}
                    className="form-control p-2 rounded-pill"
                />
                <br />
                <input
                    type="text"
                    placeholder="Course"
                    name="std_course"
                    value={student.std_course}
                    onChange={handleChange}
                    className="form-control p-2 rounded-pill"
                />
                <br />

                <div className="mb-3">
                    Gender:
                    <input
                        type="radio"
                        name="std_gender"
                        value="Male"
                        checked={student.std_gender === "Male"}
                        onChange={handleChange}
                        className="form-check-input ms-2"
                    />{" "}
                    Male
                    <input
                        type="radio"
                        name="std_gender"
                        value="Female"
                        checked={student.std_gender === "Female"}
                        onChange={handleChange}
                        className="form-check-input ms-2"
                    />{" "}
                    Female
                </div>

                <input
                    type="text"
                    placeholder="Sports"
                    name="std_sports"
                    value={student.std_sports}
                    onChange={handleChange}
                    className="form-control p-2 rounded-pill"
                />
                <br />

                <input
                    type="file"
                    name="std_photo"
                    onChange={handleChange}
                    ref={fileInputRef}
                    className="form-control p-2 rounded-pill"
                />
                <br />

                {/* Current photo or preview */}
                {student.std_photo && (
                    <div className="mb-3">
                        <img
                            src={
                                typeof student.std_photo === "string"
                                    ? student.std_photo
                                    : URL.createObjectURL(student.std_photo)
                            }
                            alt="Student"
                            className="img-thumbnail mt-2"
                            style={{ maxWidth: "150px" }}
                        />
                        <br />
                        <button
                            type="button"
                            className="btn btn-secondary btn-sm mt-2"
                            onClick={handleRemovePhoto}
                        >
                            Remove Photo
                        </button>
                    </div>
                )}

                <input type="submit" className="btn btn-primary" />
            </form>
        </div>
    );
}

export default UpdateStudent;
